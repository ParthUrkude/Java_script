// Practical 3: Control structures and form validation; grading based on marks

const form = document.createElement("form");
form.innerHTML = `
  <h2>Student Grading System</h2>
  <label>Student name: <input id="studentName" required></label><br><br>
  <label>Marks (0-100): <input id="marks" type="number" min="0" max="100" required></label><br><br>
  <button type="submit">Calculate Grade</button>
  <p id="result" aria-live="polite"></p>
`;
document.body.append(form);

form.addEventListener("submit", event => {
  event.preventDefault();
  const name = document.getElementById("studentName").value.trim();
  const marks = Number(document.getElementById("marks").value);
  const result = document.getElementById("result");

  if (!name || !Number.isFinite(marks) || marks < 0 || marks > 100) {
    result.textContent = "Please enter a valid name and marks between 0 and 100.";
    return;
  }

  let grade;
  if (marks >= 90) grade = "A+";
  else if (marks >= 80) grade = "A";
  else if (marks >= 70) grade = "B";
  else if (marks >= 60) grade = "C";
  else if (marks >= 40) grade = "D";
  else grade = "F";

  result.textContent = `${name}, your grade is ${grade}.`;
});
