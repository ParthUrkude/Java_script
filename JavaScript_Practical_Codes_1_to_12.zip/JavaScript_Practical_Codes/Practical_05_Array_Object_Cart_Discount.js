// Practical 5: Array methods, object handling and shopping cart discount calculator

const cart = [
  { id: 1, name: "Keyboard", price: 1200, quantity: 1 },
  { id: 2, name: "Mouse", price: 500, quantity: 2 },
  { id: 3, name: "USB Cable", price: 200, quantity: 3 }
];

// Array methods: map, filter, reduce, find
const cartRows = cart.map(item => ({
  ...item,
  amount: item.price * item.quantity
}));
const expensiveItems = cart.filter(item => item.price >= 500);
const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
const foundItem = cart.find(item => item.name === "Mouse");

// 10% discount for bills of ₹2,000 or more
const discountRate = subtotal >= 2000 ? 0.10 : 0;
const discount = subtotal * discountRate;
const finalTotal = subtotal - discount;

console.table(cartRows);
console.log("Items costing ₹500 or more:", expensiveItems);
console.log("Found item:", foundItem);

document.body.innerHTML = `
  <h2>Shopping Cart</h2>
  <ul>${cartRows.map(item => `<li>${item.name} × ${item.quantity}: ₹${item.amount}</li>`).join("")}</ul>
  <p>Subtotal: ₹${subtotal.toFixed(2)}</p>
  <p>Discount: ₹${discount.toFixed(2)} (${discountRate * 100}%)</p>
  <h3>Final total: ₹${finalTotal.toFixed(2)}</h3>
`;
