// Practical 1: Inline, internal and external JavaScript; console methods; user info and welcome message
// Link this file in HTML using: <script src="Practical_01_JavaScript_Basics.js"></script>

console.log("JavaScript practical started");
console.info("This is an information message");
console.warn("This is a warning message");
console.error("This is an example error message");
console.table([
  { name: "Aarav", course: "Computer Science", year: 3 },
  { name: "Diya", course: "Information Technology", year: 2 }
]);

const userName = prompt("Enter your name:");
const userCourse = prompt("Enter your course:");

const name = userName?.trim() || "Student";
const course = userCourse?.trim() || "Not specified";

document.addEventListener("DOMContentLoaded", () => {
  document.body.innerHTML = `
    <main style="font-family: Arial; padding: 24px">
      <h1>Welcome, ${escapeHTML(name)}!</h1>
      <p>Your course: ${escapeHTML(course)}</p>
      <p>Have a great day learning JavaScript.</p>
    </main>
  `;
});

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}
