// Practical 11: setTimeout(), setInterval(), ES6 module import/export and countdown.
// Save this file as an ES module and load it from HTML using:
// <script type="module" src="Practical_11_Timer_ES6_Modules_Countdown.js"></script>

// ES6 module export
export function formatTime(totalSeconds) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

document.body.innerHTML = `
  <main style="font-family:Arial;text-align:center;padding:30px">
    <h2>Countdown Timer</h2>
    <h1 id="clock">01:00</h1>
    <button id="start">Start</button>
    <button id="reset">Reset</button>
    <p id="notice"></p>
  </main>
`;

let remaining = 60;
let intervalId = null;
const clock = document.getElementById("clock");
const notice = document.getElementById("notice");

function updateClock() {
  clock.textContent = formatTime(remaining);
}

document.getElementById("start").addEventListener("click", () => {
  if (intervalId !== null) return;
  notice.textContent = "Countdown running...";
  intervalId = setInterval(() => {
    remaining--;
    updateClock();
    if (remaining <= 0) {
      clearInterval(intervalId);
      intervalId = null;
      notice.textContent = "Time is up!";
      setTimeout(() => alert("Countdown completed!"), 100);
    }
  }, 1000);
});

document.getElementById("reset").addEventListener("click", () => {
  clearInterval(intervalId);
  intervalId = null;
  remaining = 60;
  notice.textContent = "Timer reset.";
  updateClock();
});

updateClock();
