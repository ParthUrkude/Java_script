// Practical 12: Real-time web app using JavaScript, jQuery, DOM, events, storage and AJAX.
// Include jQuery before this file:
// <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

document.body.innerHTML = `
  <main style="font-family:Arial;max-width:600px;margin:24px auto;padding:16px">
    <h2>Live User Directory</h2>
    <input id="search" placeholder="Search users by name">
    <button id="refresh">Refresh data</button>
    <p id="status">Press Refresh data to load users.</p>
    <ul id="users"></ul>
  </main>
`;

const searchInput = document.getElementById("search");
const userList = document.getElementById("users");
const statusText = document.getElementById("status");
let users = JSON.parse(localStorage.getItem("cachedUsers") || "[]");

function displayUsers() {
  const query = searchInput.value.toLowerCase().trim();
  const filtered = users.filter(user => user.name.toLowerCase().includes(query));
  userList.replaceChildren();

  filtered.forEach(user => {
    const li = document.createElement("li");
    li.textContent = `${user.name} — ${user.email}`;
    userList.appendChild(li);
  });

  if (filtered.length === 0) userList.textContent = "No matching users.";
}

function loadUsers() {
  statusText.textContent = "Loading users from server...";
  if (!window.jQuery) {
    statusText.textContent = "jQuery is missing. Add the jQuery CDN script before this file.";
    return;
  }

  // AJAX request through jQuery
  $.ajax({
    url: "https://jsonplaceholder.typicode.com/users",
    method: "GET",
    dataType: "json"
  })
  .done(data => {
    users = data;
    localStorage.setItem("cachedUsers", JSON.stringify(users));
    displayUsers();
    statusText.textContent = `Loaded ${users.length} users successfully.`;
  })
  .fail(() => {
    statusText.textContent = "Server request failed. Showing saved data, if available.";
    displayUsers();
  });
}

searchInput.addEventListener("input", displayUsers);
document.getElementById("refresh").addEventListener("click", loadUsers);

// Show cached data immediately, then fetch updated data.
if (users.length) displayUsers();
loadUsers();
