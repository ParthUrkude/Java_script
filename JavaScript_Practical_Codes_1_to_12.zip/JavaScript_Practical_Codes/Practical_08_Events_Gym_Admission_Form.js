// Practical 8: Events and form-field validation; gym admission form with live checks

document.body.innerHTML = `
  <main style="font-family:Arial;max-width:480px;margin:24px auto">
    <h2>Gym Admission Form</h2>
    <form id="gymForm" novalidate>
      <p><input id="fullName" placeholder="Full name"></p>
      <p><input id="email" type="email" placeholder="Email address"></p>
      <p><input id="age" type="number" placeholder="Age"></p>
      <p>
        <select id="plan">
          <option value="">Select membership</option>
          <option>Monthly</option><option>Quarterly</option><option>Yearly</option>
        </select>
      </p>
      <p id="liveMessage" aria-live="polite">Fill in the form fields.</p>
      <button type="submit">Submit</button>
    </form>
    <p id="result"></p>
  </main>
`;

const form = document.getElementById("gymForm");
const message = document.getElementById("liveMessage");
const result = document.getElementById("result");
const fields = ["fullName", "email", "age", "plan"].map(id => document.getElementById(id));

function validateForm() {
  const [name, email, age, plan] = fields.map(field => field.value.trim());
  const valid = name.length >= 2 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) &&
    Number(age) >= 16 && Number(age) <= 80 && plan !== "";

  message.textContent = valid
    ? "All fields look valid."
    : "Enter a name, valid email, age 16–80 and membership plan.";
  message.style.color = valid ? "green" : "crimson";
  return valid;
}

fields.forEach(field => {
  field.addEventListener("input", validateForm);
  field.addEventListener("change", validateForm);
});

form.addEventListener("submit", event => {
  event.preventDefault();
  result.textContent = validateForm()
    ? "Gym admission form submitted successfully!"
    : "Please correct the form details.";
});
