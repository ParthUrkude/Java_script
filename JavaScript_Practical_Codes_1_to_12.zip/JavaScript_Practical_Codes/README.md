# JavaScript Practicals (1–12)

Each practical has one JavaScript file named according to its practical number and topic.

## How to run
1. Create a folder for the practical in your GitHub repository.
2. Add the corresponding `.js` file.
3. Create a simple `index.html` file and link the JavaScript file:
   ```html
   <!doctype html>
   <html>
   <head><meta charset="UTF-8"><title>JavaScript Practical</title></head>
   <body>
     <script src="Practical_01_JavaScript_Basics.js"></script>
   </body>
   </html>
   ```
4. Open `index.html` in a browser (or use VS Code Live Server).

## Notes
- Practical 10 and 12 require jQuery. Add this before the practical JS file:
  `<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>`
- Practical 11 uses ES modules. Load it with:
  `<script type="module" src="Practical_11_Timer_ES6_Modules_Countdown.js"></script>`
- Practical 10 and 12 use the public JSONPlaceholder test API and need an internet connection.
- These are browser-based examples; run them through an HTML page, not directly with `node`.
