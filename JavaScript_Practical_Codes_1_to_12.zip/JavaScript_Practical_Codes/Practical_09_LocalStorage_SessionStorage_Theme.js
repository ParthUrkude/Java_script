// Practical 9: localStorage and sessionStorage for saving user preferences

document.body.innerHTML = `
  <main style="font-family:Arial;padding:24px">
    <h2>Theme Preference</h2>
    <label>Choose theme:
      <select id="theme">
        <option value="light">Light</option>
        <option value="dark">Dark</option>
      </select>
    </label>
    <p id="status"></p>
  </main>
`;

const themeSelect = document.getElementById("theme");
const status = document.getElementById("status");

// localStorage keeps the preference after the browser is closed.
const savedTheme = localStorage.getItem("preferredTheme") || "light";
themeSelect.value = savedTheme;
applyTheme(savedTheme);

themeSelect.addEventListener("change", () => {
  const theme = themeSelect.value;
  localStorage.setItem("preferredTheme", theme);
  // sessionStorage remains available only for this browser tab session.
  sessionStorage.setItem("lastSelectedTheme", theme);
  applyTheme(theme);
});

function applyTheme(theme) {
  document.body.style.background = theme === "dark" ? "#222" : "#fff";
  document.body.style.color = theme === "dark" ? "#fff" : "#222";
  status.textContent = `Current theme: ${theme}. Saved in localStorage.`;
}
