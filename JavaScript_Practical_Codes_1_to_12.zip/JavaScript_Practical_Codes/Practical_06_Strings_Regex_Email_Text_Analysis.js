// Practical 6: String functions, regular expressions, data extraction and text analysis

const text = prompt("Enter text containing an email address:") ||
  "Contact student@example.com for more information about JavaScript.";

const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
const emails = text.match(emailRegex) || [];
const words = text.trim().split(/\s+/).filter(Boolean);
const characters = text.length;
const vowels = (text.match(/[aeiou]/gi) || []).length;
const upperText = text.toUpperCase();
const lowerText = text.toLowerCase();

console.log("Original:", text);
console.log("Uppercase:", upperText);
console.log("Lowercase:", lowerText);
console.log("Extracted emails:", emails);
console.log("Word count:", words.length);
console.log("Character count:", characters);
console.log("Vowel count:", vowels);

document.body.innerHTML = `
  <h2>Text Analysis</h2>
  <p><b>Original text:</b> ${escapeHTML(text)}</p>
  <p><b>Emails found:</b> ${emails.length ? emails.map(escapeHTML).join(", ") : "None"}</p>
  <p><b>Words:</b> ${words.length} | <b>Characters:</b> ${characters} | <b>Vowels:</b> ${vowels}</p>
`;
function escapeHTML(value) {
  return value.replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
