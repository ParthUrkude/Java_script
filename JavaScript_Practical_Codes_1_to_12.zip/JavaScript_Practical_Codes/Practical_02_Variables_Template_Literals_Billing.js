// Practical 2: var, let, const, template literals, destructuring and billing calculator

var shopName = "Smart Store"; // function-scoped
let customerName = prompt("Customer name:") || "Guest"; // block-scoped
const taxRate = 0.05; // cannot be reassigned

const products = [
  { name: "Notebook", price: 50, quantity: 2 },
  { name: "Pen", price: 10, quantity: 3 },
  { name: "Bag", price: 600, quantity: 1 }
];

const [{ name: firstProduct }, ...otherProducts] = products; // destructuring
console.log("First product:", firstProduct, "Other products:", otherProducts);

const subtotal = products.reduce((sum, item) => sum + item.price * item.quantity, 0);
const tax = subtotal * taxRate;
const total = subtotal + tax;

const bill = `
${shopName}
Customer: ${customerName}
-----------------------------
${products.map(p => `${p.name} x ${p.quantity} = ₹${p.price * p.quantity}`).join("\n")}
-----------------------------
Subtotal: ₹${subtotal.toFixed(2)}
Tax (5%): ₹${tax.toFixed(2)}
Total: ₹${total.toFixed(2)}
`;

console.log(bill);
document.body.innerHTML = `<pre style="font:16px monospace; padding:20px">${bill}</pre>`;
