// Practical 7: DOM traversal and updates; add, edit and delete to-do items

document.body.innerHTML = `
  <main style="font-family:Arial;max-width:520px;margin:30px auto">
    <h2>My To-Do List</h2>
    <form id="todoForm">
      <input id="todoInput" placeholder="Enter a task" required>
      <button>Add</button>
    </form>
    <ul id="todoList"></ul>
  </main>
`;

const form = document.getElementById("todoForm");
const input = document.getElementById("todoInput");
const list = document.getElementById("todoList");

form.addEventListener("submit", event => {
  event.preventDefault();
  const taskText = input.value.trim();
  if (!taskText) return;

  const li = document.createElement("li");
  const task = document.createElement("span");
  task.textContent = taskText;

  const editButton = document.createElement("button");
  editButton.textContent = "Edit";
  editButton.type = "button";
  editButton.addEventListener("click", () => {
    const updated = prompt("Edit task:", task.textContent);
    if (updated?.trim()) task.textContent = updated.trim();
  });

  const deleteButton = document.createElement("button");
  deleteButton.textContent = "Delete";
  deleteButton.type = "button";
  deleteButton.addEventListener("click", () => {
    // DOM traversal: remove the current list item from its parent list
    deleteButton.parentElement.remove();
  });

  li.append(task, " ", editButton, " ", deleteButton);
  list.appendChild(li);
  input.value = "";
});
