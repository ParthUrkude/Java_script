// Practical 4: Function types, scope, closures, try-catch and palindrome checker

// Function declaration
function greet(name) {
  return `Hello, ${name}!`;
}

// Function expression
const square = function (number) {
  return number * number;
};

// Arrow function
const isEven = number => number % 2 === 0;

// Closure: inner function remembers the outer variable
function createCounter() {
  let count = 0;
  return function () {
    return ++count;
  };
}
const counter = createCounter();

function isPalindrome(value) {
  const cleaned = value.toLowerCase().replace(/[^a-z0-9]/g, "");
  if (!cleaned) throw new Error("Please enter some text.");
  return cleaned === [...cleaned].reverse().join("");
}

const input = prompt("Enter a word or sentence to check palindrome:");
try {
  const answer = isPalindrome(input ?? "");
  console.log(greet("Student"));
  console.log("Square of 5:", square(5));
  console.log("Is 8 even?", isEven(8));
  console.log("Closure counter:", counter(), counter());
  document.body.textContent = answer ? "It is a palindrome." : "It is not a palindrome.";
} catch (error) {
  document.body.textContent = `Error: ${error.message}`;
}
