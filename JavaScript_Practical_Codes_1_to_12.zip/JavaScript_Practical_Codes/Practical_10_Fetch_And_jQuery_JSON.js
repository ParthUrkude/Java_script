// Practical 10: Load JSON using fetch() and jQuery $.getJSON(), then render a table.
// For the jQuery section, include this before this file in HTML:
// <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

document.body.innerHTML = `
  <main style="font-family:Arial;padding:20px">
    <h2>Users loaded with Fetch</h2>
    <div id="fetchOutput">Loading...</div>
    <h2>Users loaded with jQuery</h2>
    <div id="jqueryOutput">Loading...</div>
  </main>
`;

const apiURL = "https://jsonplaceholder.typicode.com/users";

function renderTable(users, targetId) {
  const target = document.getElementById(targetId);
  target.innerHTML = `
    <table border="1" cellpadding="8" cellspacing="0">
      <tr><th>ID</th><th>Name</th><th>Email</th><th>City</th></tr>
      ${users.map(user => `
        <tr>
          <td>${user.id}</td><td>${escapeHTML(user.name)}</td>
          <td>${escapeHTML(user.email)}</td><td>${escapeHTML(user.address.city)}</td>
        </tr>`).join("")}
    </table>`;
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

// Fetch API
fetch(apiURL)
  .then(response => {
    if (!response.ok) throw new Error("Network response was not OK");
    return response.json();
  })
  .then(users => renderTable(users, "fetchOutput"))
  .catch(error => document.getElementById("fetchOutput").textContent = error.message);

// jQuery getJSON
if (window.jQuery) {
  $.getJSON(apiURL)
    .done(users => renderTable(users, "jqueryOutput"))
    .fail(() => document.getElementById("jqueryOutput").textContent = "Could not load JSON using jQuery.");
} else {
  document.getElementById("jqueryOutput").textContent = "Add the jQuery CDN script to use $.getJSON().";
}
